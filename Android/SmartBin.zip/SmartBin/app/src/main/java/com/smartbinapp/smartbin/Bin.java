package com.smartbinapp.smartbin;

/**
 * Created by Priti_Parate on 10/19/2015.
 */
public class Bin {
    int Id;
    Double latitude;
    Double longitude;
    float fill;
    String location;
    float humadity;
    Double temp;


}
